# AI Predictive Maintenance for Industry 4.0 (MERN)

MongoDB + Express + React + Node implementation of the two base papers:

* **Paper 1** - *Predictive Maintenance Using AI for Enhancing Operational Efficiency in Industry 4.0*
* **Paper 2** - *A Survey on Intelligent Predictive Maintenance (IPdM) in the Era of Fully Connected Intelligence*

## Run it (no Docker)

Requirements:
* Node.js 18+ (https://nodejs.org)
* MongoDB Community Server running on localhost:27017 (https://www.mongodb.com/try/download/community)
  * Windows: runs as a service after install
  * macOS: `brew services start mongodb-community`
  * Linux: `sudo systemctl start mongod`

Then, in the project folder (e.g. in the VS Code terminal):

```bash
npm run install-all
npm run dev
```

Open **http://localhost:5173**.

The connection string is in `server/.env` (`MONGO_URI=mongodb://127.0.0.1:27017/pdm_industry40`);
paste a MongoDB Atlas string there if you prefer the cloud.

On first start the API trains the failure model on the **ForgeSight dataset** (`server/data/forgesight_dataset_001.csv`, 6,000 rows, train/test split column) and seeds 5 demo machines, so the dashboard
shows output immediately (`npm run seed` or the "Reset demo data" button re-seeds).

### Windows: "An Application Control policy has blocked this file" (rollup / esbuild)
Some Windows PCs block unsigned native `.node` / `.exe` files. This project's client is already configured to use the
pure-JavaScript/WebAssembly builds of Rollup and esbuild (see `overrides` in `client/package.json`), so no native
binaries are needed. If you installed an earlier copy, do a clean install:

```bash
cd client
rmdir /s /q node_modules      # PowerShell: Remove-Item -Recurse -Force node_modules
del package-lock.json         # PowerShell: Remove-Item package-lock.json
npm install
npm run dev
```

## What you see

| Screen | Output |
|---|---|
| Dashboard | Fleet health, failure probability, RUL, anomaly flag, priority, availability, OEE, expected loss |
| Machine detail | Health Index + failure-probability curves, live sensor charts, maintenance decision, explainability (top risk drivers), **Simulate N hours** and **Perform maintenance** buttons |
| Impact & ROI | Downtime reduction, cost saving, ROI, reliability improvement, carbon reduction |

Try: open *Conveyor Motor #7*, click **Simulate 10 h** a few times and watch health fall,
priority escalate to CRITICAL, and finally the machine FAIL; then click **Perform maintenance**.

## How the papers map to the code

IPdM lifecycle (Paper 2, Fig. 7) -> `server/services/`

| Stage | File | Technique |
|---|---|---|
| 1 Data acquisition (device layer) | `dataset.js`, `simulator.js`, `POST /api/machines/:id/readings` | ForgeSight dataset loader; simulated IIoT sensors calibrated to it: temperature, vibration, rpm, operating hours |
| 2 Pre-processing (edge layer) | `preprocess.js` | Carry-forward imputation, clipping, min-max `X' = (X-Xmin)/(Xmax-Xmin)` using dataset ranges |
| 3 Diagnosis & prognosis (cloud layer) | `mlService.js`, `pipeline.js` | Health Index `HI = Σ wᵢxᵢ`; logistic regression `P = 1/(1+e^-z)` trained by gradient descent on the dataset `train` split and evaluated on `test` (~83% test accuracy); RUL = `Tf - Tc` from HI-trend regression; z-score anomaly detection; reliability `R(t)=e^(-λt)`; feature contributions for XAI |
| 4 Decision making | `pipeline.js → decide()` | Rule + cost based: priority and action, expected loss vs preventive cost |
| KPIs | `kpi.js` | Availability, `OE = αA+βQ+γP`, DR, CS, ROI, RI, CE |

## API

```
GET    /api/dashboard                 fleet summary
POST   /api/dashboard/seed            reset demo data
GET    /api/model                     dataset summary + train/test metrics (accuracy, precision, recall, F1, confusion)
POST   /api/model/predict             { temperature_C, vibration, rpm, operating_hours } -> failure probability
GET    /api/machines                  list
POST   /api/machines                  create
GET    /api/machines/:id              machine + latest prediction + KPIs
GET    /api/machines/:id/series       chart data (HI, probability, sensors)
POST   /api/machines/:id/readings     ingest one real sensor reading -> prediction
POST   /api/machines/:id/simulate     { steps } simulate operation
POST   /api/machines/:id/maintain     perform maintenance
POST   /api/kpi/impact                { Dc,Dp,Cc,Cp,B,C,Rc,Rp,COb,COa }
```

Send real data with e.g.:
```bash
curl -X POST localhost:5000/api/machines/<id>/readings -H "Content-Type: application/json" \
  -d '{"temperature":88,"vibration":6.2,"rpm":1430,"operating_hours":18000}'
```

## Dataset

`server/data/forgesight_dataset_001.csv` - columns `temperature_C, vibration, rpm, operating_hours, failure, split`.
The model, normalisation ranges, healthy baseline (anomaly detector) and Health-Index weights all come from it.
The dashboard shows the dataset/model metrics and a "Predict failure" form. To use another file with the same columns,
replace the CSV or set `DATASET_PATH` in `server/.env`.

## Notes
* Machine sensor streams are still simulated (calibrated to the dataset) so the demo works live; post real readings to the readings endpoint.
* The logistic model and linear RUL are intentionally lightweight. The `pipeline.js` interface lets you swap in another model without changing the API or UI.

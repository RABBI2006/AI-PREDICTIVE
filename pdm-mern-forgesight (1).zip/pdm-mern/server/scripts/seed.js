require('dotenv').config();
const mongoose = require('mongoose');
const connectDB = require('../config/db');
const { seedDatabase } = require('../services/seed');
const { trainModel } = require('../services/mlService');

(async () => {
  await connectDB();
  trainModel();
  const n = await seedDatabase();
  console.log(`Seeded ${n} machines with sensor history and predictions.`);
  await mongoose.disconnect();
})();

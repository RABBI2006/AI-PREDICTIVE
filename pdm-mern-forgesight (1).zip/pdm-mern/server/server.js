require('dotenv').config();
const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const connectDB = require('./config/db');
const Machine = require('./models/Machine');
const { trainModel } = require('./services/mlService');
const { seedDatabase } = require('./services/seed');

const app = express();
app.use(cors());
app.use(express.json());
app.use(morgan('dev'));

app.get('/api/health', (_req, res) => res.json({ ok: true }));
app.use('/api/machines', require('./routes/machines'));
app.use('/api/dashboard', require('./routes/dashboard'));
app.use('/api/kpi', require('./routes/kpi'));
app.use('/api/model', require('./routes/model'));

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: err.message });
});

const PORT = process.env.PORT || 5000;

(async () => {
  try {
    await connectDB();
  } catch (e) {
    console.error('\nCould not connect to MongoDB. Start it first (make sure the mongod service is running) and check MONGO_URI in server/.env\n');
    process.exit(1);
  }
  const m = trainModel();
  console.log(`Failure model trained on ${m.dataset} (${m.train.samples} train rows). Test accuracy: ${(m.test.accuracy * 100).toFixed(1)}% (${m.test.samples} test rows), F1 ${(m.test.f1 * 100).toFixed(1)}%`);
  if ((await Machine.countDocuments()) === 0) {
    const n = await seedDatabase();
    console.log(`Seeded demo fleet (${n} machines).`);
  }
  app.listen(PORT, () => console.log(`API running on http://localhost:${PORT}`));
})();

const router = require('express').Router();
const { load } = require('../services/dataset');
const { getModel, getHIWeights, failureProbability, contributions } = require('../services/mlService');
const { toFeatures, FEATURE_NAMES } = require('../services/preprocess');

// dataset + model metrics
router.get('/', (_req, res) => {
  const ds = load();
  const m = getModel();
  res.json({
    dataset: { file: ds.file, rows: ds.rows.length, train: ds.train.length, test: ds.test.length, failureRate: ds.failureRate, ranges: ds.ranges },
    model: {
      type: 'Logistic regression (gradient descent)',
      features: FEATURE_NAMES, weights: m.w, bias: m.b, healthIndexWeights: getHIWeights(),
      train: m.train, test: m.test,
    },
  });
});

// predict failure for one set of dataset-style inputs
router.post('/predict', (req, res) => {
  const b = req.body || {};
  const r = {
    temperature: +(b.temperature_C ?? b.temperature),
    vibration: +b.vibration,
    rpm: +b.rpm,
    operating_hours: +b.operating_hours,
  };
  if (Object.values(r).some(Number.isNaN)) {
    return res.status(400).json({ error: 'Send numeric temperature_C, vibration, rpm and operating_hours' });
  }
  const f = toFeatures(r);
  const p = failureProbability(f);
  const c = contributions(f);
  res.json({
    failureProbability: +p.toFixed(4),
    prediction: p >= 0.5 ? 'failure' : 'no failure',
    drivers: FEATURE_NAMES.map((feature, i) => ({ feature, contribution: +c[i].toFixed(3) })).sort((a, b) => b.contribution - a.contribution),
  });
});

module.exports = router;

const router = require('express').Router();
const { impact } = require('../services/kpi');

// body: { Dc, Dp, Cc, Cp, B, C, Rc, Rp, COb, COa }
router.post('/impact', (req, res) => res.json(impact(req.body)));

module.exports = router;

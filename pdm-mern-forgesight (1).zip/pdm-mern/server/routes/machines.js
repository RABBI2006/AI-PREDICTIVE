const router = require('express').Router();
const Machine = require('../models/Machine');
const SensorReading = require('../models/SensorReading');
const Prediction = require('../models/Prediction');
const { analyze, buildSeries } = require('../services/pipeline');
const { generateReading } = require('../services/simulator');
const { availability, operationalEfficiency } = require('../services/kpi');

const WINDOW = 120;
const lastReadings = async (id, n = WINDOW) =>
  (await SensorReading.find({ machine: id }).sort({ hour: -1 }).limit(n).lean()).reverse();

async function runAndStore(machine) {
  const readings = await lastReadings(machine._id);
  if (!readings.length) return null;
  const p = analyze(machine, readings);
  return Prediction.create({ machine: machine._id, ...p });
}

// list
router.get('/', async (_req, res) => {
  const machines = await Machine.find().lean();
  res.json(machines);
});

// create
router.post('/', async (req, res) => {
  const m = await Machine.create(req.body);
  // initial healthy history so the models have data
  const docs = [];
  for (let i = 1; i <= 30; i++) docs.push({ machine: m._id, hour: i, ...generateReading(m.degradation) });
  await SensorReading.insertMany(docs);
  m.hour = 30; await m.save();
  await runAndStore(m);
  res.status(201).json(m);
});

// detail + latest prediction + KPIs
router.get('/:id', async (req, res) => {
  const m = await Machine.findById(req.params.id).lean();
  if (!m) return res.status(404).json({ error: 'Machine not found' });
  const prediction = await Prediction.findOne({ machine: m._id }).sort({ createdAt: -1 }).lean();
  const A = availability(m.operatingHours, m.downtimeHours);
  const kpi = {
    availability: +A.toFixed(4),
    oee: +operationalEfficiency(A, m.quality, m.performance).toFixed(4),
  };
  res.json({ machine: m, prediction, kpi });
});

// time series for charts
router.get('/:id/series', async (req, res) => {
  const limit = Math.min(+req.query.limit || 100, 500);
  const readings = await lastReadings(req.params.id, limit);
  res.json(buildSeries(readings));
});

// prediction history
router.get('/:id/predictions', async (req, res) => {
  const preds = await Prediction.find({ machine: req.params.id }).sort({ createdAt: -1 }).limit(50).lean();
  res.json(preds.reverse());
});

// ingest real sensor data (IIoT endpoint)
router.post('/:id/readings', async (req, res) => {
  const m = await Machine.findById(req.params.id);
  if (!m) return res.status(404).json({ error: 'Machine not found' });
  m.hour += 1;
  if (m.status === 'running') m.operatingHours += 1;
  await SensorReading.create({ machine: m._id, hour: m.hour, ...req.body });
  await m.save();
  const prediction = await runAndStore(m);
  res.status(201).json(prediction);
});

// simulate N hours of operation (digital-twin step)
router.post('/:id/simulate', async (req, res) => {
  const m = await Machine.findById(req.params.id);
  if (!m) return res.status(404).json({ error: 'Machine not found' });
  if (m.status === 'failed') {
    const prediction = await Prediction.findOne({ machine: m._id }).sort({ createdAt: -1 });
    return res.json({ machine: m, prediction, note: 'Machine already failed - perform maintenance.' });
  }
  const steps = Math.min(Math.max(+req.body.steps || 1, 1), 100);
  const docs = [];
  for (let i = 0; i < steps; i++) {
    m.degradation = Math.min(1, m.degradation + m.degradationRate * (0.6 + Math.random() * 0.8));
    m.hour += 1;
    m.operatingHours += 1;
    docs.push({ machine: m._id, hour: m.hour, ...generateReading(m.degradation) });
    if (m.degradation >= 1) {
      m.status = 'failed';
      m.downtimeHours += m.repairDowntimeHours;
      break;
    }
  }
  await SensorReading.insertMany(docs);
  await m.save();
  const prediction = await runAndStore(m);
  res.json({ machine: m, prediction });
});

// perform maintenance (resets the machine, logs the intervention)
router.post('/:id/maintain', async (req, res) => {
  const m = await Machine.findById(req.params.id);
  if (!m) return res.status(404).json({ error: 'Machine not found' });
  const wasFailed = m.status === 'failed';
  m.degradation = 0.02;
  m.status = 'running';
  if (!wasFailed) m.downtimeHours += 4; // planned stop is cheaper than failure
  m.maintenanceLog.push({ at: new Date(), note: wasFailed ? 'Corrective repair' : 'Predictive maintenance' });
  // fresh healthy readings
  const docs = [];
  for (let i = 0; i < 10; i++) { m.hour += 1; docs.push({ machine: m._id, hour: m.hour, ...generateReading(0.02) }); }
  await SensorReading.insertMany(docs);
  await m.save();
  const prediction = await runAndStore(m);
  res.json({ machine: m, prediction });
});

router.delete('/:id', async (req, res) => {
  await Promise.all([
    Machine.findByIdAndDelete(req.params.id),
    SensorReading.deleteMany({ machine: req.params.id }),
    Prediction.deleteMany({ machine: req.params.id }),
  ]);
  res.json({ ok: true });
});

module.exports = router;

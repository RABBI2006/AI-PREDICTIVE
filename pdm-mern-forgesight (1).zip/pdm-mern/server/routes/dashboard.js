const router = require('express').Router();
const Machine = require('../models/Machine');
const Prediction = require('../models/Prediction');
const { availability, operationalEfficiency } = require('../services/kpi');
const { seedDatabase } = require('../services/seed');
const { getModel } = require('../services/mlService');

router.get('/', async (_req, res) => {
  const machines = await Machine.find().lean();
  const rows = [];
  for (const m of machines) {
    const prediction = await Prediction.findOne({ machine: m._id }).sort({ createdAt: -1 }).lean();
    const A = availability(m.operatingHours, m.downtimeHours);
    rows.push({ ...m, prediction, availability: A, oee: operationalEfficiency(A, m.quality, m.performance) });
  }
  const count = (p) => rows.filter((r) => r.prediction?.priority === p).length;
  const avg = (f) => (rows.length ? rows.reduce((s, r) => s + f(r), 0) / rows.length : 0);
  const op = rows.reduce((s, r) => s + r.operatingHours, 0);
  const down = rows.reduce((s, r) => s + r.downtimeHours, 0);

  const mdl = getModel();
  res.json({
    machines: rows,
    summary: {
      total: rows.length,
      critical: count('critical'), high: count('high'), medium: count('medium'), low: count('low'),
      avgHealth: avg((r) => r.prediction?.healthIndex ?? 0),
      fleetAvailability: availability(op, down),
      avgOEE: avg((r) => r.oee),
      totalExpectedLoss: rows.reduce((s, r) => s + (r.prediction?.expectedLoss ?? 0), 0),
      modelAccuracy: mdl.accuracy ?? null,
    },
  });
});

router.post('/seed', async (_req, res) => {
  const n = await seedDatabase();
  res.json({ seeded: n });
});

module.exports = router;

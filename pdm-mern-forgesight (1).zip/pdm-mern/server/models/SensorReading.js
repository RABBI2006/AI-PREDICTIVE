const mongoose = require('mongoose');

// Same four inputs as the ForgeSight dataset
const SensorReadingSchema = new mongoose.Schema({
  machine: { type: mongoose.Schema.Types.ObjectId, ref: 'Machine', index: true },
  hour: Number,
  temperature: Number,      // deg C   (dataset: temperature_C)
  vibration: Number,        // mm/s
  rpm: Number,
  operating_hours: Number,  // accumulated machine operating hours
}, { timestamps: true });

module.exports = mongoose.model('SensorReading', SensorReadingSchema);

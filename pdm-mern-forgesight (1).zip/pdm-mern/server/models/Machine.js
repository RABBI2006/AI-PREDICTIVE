const mongoose = require('mongoose');

const MachineSchema = new mongoose.Schema({
  name: { type: String, required: true },
  type: { type: String, default: 'Motor' },
  location: { type: String, default: 'Plant A' },
  status: { type: String, enum: ['running', 'failed'], default: 'running' },

  // simulation / digital-twin state
  degradation: { type: Number, default: 0.02 },      // 0 = new, 1 = failed
  degradationRate: { type: Number, default: 0.006 }, // per hour
  hour: { type: Number, default: 0 },

  // KPI inputs (Paper 1, Sec. 4.6-4.7, 6.x)
  operatingHours: { type: Number, default: 0 },
  downtimeHours: { type: Number, default: 0 },
  quality: { type: Number, default: 0.97 },
  performance: { type: Number, default: 0.92 },
  baseFailureRate: { type: Number, default: 0.002 }, // lambda (failures/hour)

  // cost model (Paper 1, Sec. 4.5)
  preventiveCost: { type: Number, default: 1500 },
  repairCost: { type: Number, default: 12000 },
  downtimeCostPerHour: { type: Number, default: 2500 },
  repairDowntimeHours: { type: Number, default: 16 },

  maintenanceLog: [{ at: Date, note: String }],
}, { timestamps: true });

module.exports = mongoose.model('Machine', MachineSchema);

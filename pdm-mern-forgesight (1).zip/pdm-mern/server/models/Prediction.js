const mongoose = require('mongoose');

const PredictionSchema = new mongoose.Schema({
  machine: { type: mongoose.Schema.Types.ObjectId, ref: 'Machine', index: true },
  hour: Number,
  healthIndex: Number,
  failureProbability: Number,
  rulHours: Number,        // null => stable / not degrading
  reliability24h: Number,
  anomalyScore: Number,
  isAnomaly: Boolean,
  priority: String,        // low | medium | high | critical
  action: String,
  expectedLoss: Number,
  preventiveCost: Number,
  topFactors: [{ feature: String, contribution: Number }],
}, { timestamps: true });

module.exports = mongoose.model('Prediction', PredictionSchema);

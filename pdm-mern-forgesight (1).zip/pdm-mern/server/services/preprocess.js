// Stage 2 - Pre-processing: missing values, outlier clipping, min-max normalisation
// X' = (X - Xmin) / (Xmax - Xmin)       (Paper 1, Sec. 3.2)
// Ranges come from the ForgeSight dataset so training and live data share one scale.
const { load } = require('./dataset');

const KEYS = ['temperature', 'vibration', 'rpm', 'operating_hours'];
const FEATURE_NAMES = ['temperature', 'vibration', 'rpm', 'operating hours'];
const MID = { temperature: 75, vibration: 4.4, rpm: 1560, operating_hours: 12500 };

const clip = (x, a = 0, b = 1) => Math.min(b, Math.max(a, x));
const norm = (key, x) => {
  const [lo, hi] = load().ranges[key];
  return clip((x - lo) / (hi - lo));
};

// carry-forward imputation for missing / NaN values
function clean(readings) {
  let last = null;
  return readings.map((r) => {
    const o = { ...r };
    for (const k of KEYS) {
      if (o[k] == null || Number.isNaN(o[k])) o[k] = last ? last[k] : MID[k];
    }
    last = o;
    return o;
  });
}

// normalised feature vector [temperature, vibration, rpm, operating_hours] in [0,1]
function toFeatures(r) {
  return KEYS.map((k) => norm(k, r[k]));
}

module.exports = { clean, toFeatures, FEATURE_NAMES, KEYS, clip };

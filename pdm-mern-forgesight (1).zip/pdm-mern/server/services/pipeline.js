// Full IPdM lifecycle: acquisition -> pre-processing -> diagnosis/prognosis -> decision
const { clean, toFeatures, FEATURE_NAMES } = require('./preprocess');
const { healthIndex, failureProbability, estimateRUL, contributions } = require('./mlService');
const { load } = require('./dataset');

// z-score anomaly detector against healthy baseline (stand-in for autoencoder)
function anomaly(latest) {
  const zs = Object.entries(load().baseline).map(([k, b]) => Math.abs((latest[k] - b.mean) / b.sd));
  const score = Math.max(...zs);
  return { score, isAnomaly: score > 3 };
}

// Stage 4 - decision making (rule + cost based)
function decide(machine, prob, rul) {
  const expectedLoss = prob * (machine.repairCost + machine.downtimeCostPerHour * machine.repairDowntimeHours);
  const preventive = machine.preventiveCost;
  let priority = 'low';
  let action = 'Continue normal operation. Keep monitoring.';

  if (machine.status === 'failed') {
    return { priority: 'critical', action: 'Machine has FAILED. Corrective repair required immediately.', expectedLoss, preventive };
  }
  if (prob > 0.8 || (rul != null && rul < 48)) {
    priority = 'critical';
    action = 'Stop machine at next safe point and perform maintenance within 24 hours.';
  } else if (prob > 0.5 || (rul != null && rul < 168)) {
    priority = 'high';
    action = 'Schedule maintenance within 48-72 hours; order spare parts now.';
  } else if (prob > 0.25 || expectedLoss > preventive) {
    priority = 'medium';
    action = 'Plan inspection in the next maintenance window; expected loss exceeds preventive cost.';
  }
  return { priority, action, expectedLoss, preventive };
}

// readings: ascending by hour (lean objects)
function analyze(machine, readings) {
  const cleaned = clean(readings);
  const feats = cleaned.map(toFeatures);
  const his = feats.map(healthIndex);
  const latestFeat = feats[feats.length - 1];
  const latest = cleaned[cleaned.length - 1];

  const hi = his.slice(-3).reduce((a, b) => a + b, 0) / Math.min(3, his.length);
  const prob = failureProbability(latestFeat);
  const rul = estimateRUL(cleaned.map((r) => r.hour), his);
  const an = anomaly(latest);

  // reliability  R(t) = exp(-lambda t), lambda inflated by degradation
  const lambda = machine.baseFailureRate * (1 + 8 * Math.pow(1 - hi, 2));
  const reliability24h = Math.exp(-lambda * 24);

  const dec = decide(machine, prob, rul);
  const contrib = contributions(latestFeat);
  const topFactors = FEATURE_NAMES
    .map((feature, i) => ({ feature, contribution: +contrib[i].toFixed(3) }))
    .sort((a, b) => b.contribution - a.contribution)
    .slice(0, 3);

  return {
    hour: latest.hour,
    healthIndex: +hi.toFixed(4),
    failureProbability: +prob.toFixed(4),
    rulHours: rul == null ? null : +rul.toFixed(1),
    reliability24h: +reliability24h.toFixed(4),
    anomalyScore: +an.score.toFixed(2),
    isAnomaly: an.isAnomaly,
    priority: dec.priority,
    action: dec.action,
    expectedLoss: Math.round(dec.expectedLoss),
    preventiveCost: dec.preventive,
    topFactors,
  };
}

// per-reading series for charts
function buildSeries(readings) {
  const cleaned = clean(readings);
  return cleaned.map((r) => {
    const f = toFeatures(r);
    return {
      hour: r.hour,
      temperature: +r.temperature.toFixed(1),
      vibration: +r.vibration.toFixed(2),
      rpm: Math.round(r.rpm),
      operating_hours: Math.round(r.operating_hours),
      hi: +healthIndex(f).toFixed(3),
      prob: +failureProbability(f).toFixed(3),
    };
  });
}

module.exports = { analyze, buildSeries };

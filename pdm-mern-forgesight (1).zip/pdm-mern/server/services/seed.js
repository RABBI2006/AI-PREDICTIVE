const Machine = require('../models/Machine');
const SensorReading = require('../models/SensorReading');
const Prediction = require('../models/Prediction');
const { generateReading } = require('./simulator');
const { analyze } = require('./pipeline');

const FLEET = [
  { name: 'CNC Mill #1',        type: 'CNC Machine', location: 'Line 1', d0: 0.08, rate: 0.004, op: 4200, down: 60 },
  { name: 'Hydraulic Pump #3',  type: 'Pump',        location: 'Line 2', d0: 0.28, rate: 0.006, op: 3900, down: 110 },
  { name: 'Air Compressor #2',  type: 'Compressor',  location: 'Utility', d0: 0.48, rate: 0.008, op: 5100, down: 190 },
  { name: 'Gas Turbine #1',     type: 'Turbine',     location: 'Power House', d0: 0.66, rate: 0.007, op: 6100, down: 240 },
  { name: 'Conveyor Motor #7',  type: 'Motor',       location: 'Line 3', d0: 0.82, rate: 0.009, op: 3500, down: 150 },
];

async function seedDatabase() {
  await Promise.all([Machine.deleteMany({}), SensorReading.deleteMany({}), Prediction.deleteMany({})]);
  const HISTORY = 80;

  for (const f of FLEET) {
    const machine = await Machine.create({
      name: f.name, type: f.type, location: f.location,
      degradation: f.d0, degradationRate: f.rate, hour: HISTORY,
      operatingHours: f.op, downtimeHours: f.down,
    });
    const docs = [];
    for (let i = 0; i < HISTORY; i++) {
      const d = Math.max(0.01, f.d0 - (HISTORY - 1 - i) * f.rate);
      docs.push({ machine: machine._id, hour: i + 1, ...generateReading(d) });
    }
    await SensorReading.insertMany(docs);
    const p = analyze(machine, docs);
    await Prediction.create({ machine: machine._id, ...p });
  }
  return FLEET.length;
}

module.exports = { seedDatabase };

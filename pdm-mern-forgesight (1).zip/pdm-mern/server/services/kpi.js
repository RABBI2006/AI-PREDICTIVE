// KPI formulas from Paper 1 (Sec. 4.6-4.9, 5.6, 6.x) and Paper 2 (Sec. II-F)
const availability = (op, down) => (op + down === 0 ? 1 : op / (op + down));

// OE = alpha*A + beta*Q + gamma*P  (alpha+beta+gamma=1)
const operationalEfficiency = (A, Q, P, w = { a: 0.4, b: 0.3, c: 0.3 }) => w.a * A + w.b * Q + w.c * P;

// impact metrics
function impact({ Dc, Dp, Cc, Cp, B, C, Rc, Rp, COb, COa }) {
  const pct = (a, b) => (a ? ((a - b) / a) * 100 : 0);
  const out = {};
  if (Dc != null && Dp != null) out.downtimeReductionPct = +pct(Dc, Dp).toFixed(2);     // DR
  if (Cc != null && Cp != null) out.costSavingPct = +pct(Cc, Cp).toFixed(2);             // CS
  if (B != null && C) out.roiPct = +(((B - C) / C) * 100).toFixed(2);                    // ROI
  if (Rc && Rp != null) out.reliabilityImprovementPct = +(((Rp - Rc) / Rc) * 100).toFixed(2); // RI
  if (COb && COa != null) out.carbonReductionPct = +(((COb - COa) / COb) * 100).toFixed(2);   // CE
  return out;
}

module.exports = { availability, operationalEfficiency, impact };

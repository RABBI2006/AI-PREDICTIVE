// Loads the ForgeSight dataset (server/data/forgesight_dataset_001.csv)
// columns: temperature_C, vibration, rpm, operating_hours, failure, split(train|test)
const fs = require('fs');
const path = require('path');

const FILE = process.env.DATASET_PATH || path.join(__dirname, '..', 'data', 'forgesight_dataset_001.csv');
const COLS = ['temperature_C', 'vibration', 'rpm', 'operating_hours'];

let cache = null;

function load() {
  if (cache) return cache;
  const lines = fs.readFileSync(FILE, 'utf8').split(/\r?\n/).filter(Boolean);
  const header = lines[0].split(',').map((s) => s.trim());
  const idx = Object.fromEntries(header.map((h, i) => [h, i]));
  for (const c of [...COLS, 'failure', 'split']) {
    if (!(c in idx)) throw new Error(`Dataset is missing column "${c}"`);
  }
  const rows = [];
  for (let i = 1; i < lines.length; i++) {
    const p = lines[i].split(',');
    const r = {
      temperature: +p[idx.temperature_C],
      vibration: +p[idx.vibration],
      rpm: +p[idx.rpm],
      operating_hours: +p[idx.operating_hours],
      failure: +p[idx.failure],
      split: p[idx.split].trim(),
    };
    if ([r.temperature, r.vibration, r.rpm, r.operating_hours, r.failure].some(Number.isNaN)) continue;
    rows.push(r);
  }

  // healthy-machine statistics (failure = 0) -> baseline for anomaly detection
  const healthy = rows.filter((r) => r.failure === 0);
  const stat = (k) => {
    const m = healthy.reduce((s, r) => s + r[k], 0) / healthy.length;
    const sd = Math.sqrt(healthy.reduce((s, r) => s + (r[k] - m) ** 2, 0) / healthy.length);
    return { mean: m, sd };
  };
  const baseline = { temperature: stat('temperature'), vibration: stat('vibration'), rpm: stat('rpm') };

  // min / max for min-max normalisation
  const ranges = {};
  for (const k of ['temperature', 'vibration', 'rpm', 'operating_hours']) {
    const v = rows.map((r) => r[k]);
    ranges[k] = [Math.min(...v), Math.max(...v)];
  }

  cache = {
    file: path.basename(FILE),
    rows,
    train: rows.filter((r) => r.split === 'train'),
    test: rows.filter((r) => r.split === 'test'),
    baseline,
    ranges,
    failureRate: rows.reduce((s, r) => s + r.failure, 0) / rows.length,
  };
  return cache;
}

module.exports = { load };

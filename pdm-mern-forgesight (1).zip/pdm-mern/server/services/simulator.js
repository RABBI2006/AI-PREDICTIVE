// Stage 1 - Data acquisition (simulated IIoT sensors / digital twin)
// Calibrated to the ForgeSight dataset: healthy machines ~71 C / 3.7 mm/s,
// failing machines ~82 C / 5.8 mm/s with higher accumulated operating hours.
const { load } = require('./dataset');
const gauss = (sd) => (Math.random() + Math.random() + Math.random() - 1.5) * 2 * sd;

// Healthy reference (used by the anomaly detector), taken from failure=0 rows of the dataset
const HEALTHY_BASELINE = new Proxy({}, {
  get: (_t, k) => load().baseline[k],
  ownKeys: () => Object.keys(load().baseline),
  getOwnPropertyDescriptor: () => ({ enumerable: true, configurable: true }),
});

// d in [0,1] : degradation level of the machine
function generateReading(d) {
  return {
    temperature: 58 + 42 * d + gauss(3),
    vibration: Math.max(0.3, 1.8 + 8.2 * Math.pow(d, 1.5) + gauss(0.4)),
    rpm: Math.max(500, 1560 + gauss(250)),
    operating_hours: Math.max(1, Math.round(1000 + 23000 * d + gauss(1500))),
  };
}

module.exports = { generateReading, HEALTHY_BASELINE };

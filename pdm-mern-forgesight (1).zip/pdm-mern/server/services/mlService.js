// Stage 3 - Diagnosis & prognosis models
const { load } = require('./dataset');
const { toFeatures, clip } = require('./preprocess');

const sigmoid = (z) => 1 / (1 + Math.exp(-z));
const N = 4;

let model = { w: new Array(N).fill(0), b: 0, trained: false };
let HI_WEIGHTS = [0.25, 0.25, 0.25, 0.25];

// ---- Health Index  HI = sum(w_i * x_i), sum(w_i)=1   (Paper 1, Sec. 3.5)
// x_i = 1 - degradation_i, so higher HI = healthier. Weights are learned from the dataset.
const healthIndex = (feats) => feats.reduce((s, f, i) => s + HI_WEIGHTS[i] * (1 - f), 0);

const predictRaw = (feats) => sigmoid(feats.reduce((s, v, j) => s + v * model.w[j], model.b));

function evaluate(X, y) {
  let tp = 0, fp = 0, tn = 0, fn = 0;
  X.forEach((f, i) => {
    const p = predictRaw(f) >= 0.5 ? 1 : 0;
    if (p && y[i]) tp++; else if (p && !y[i]) fp++; else if (!p && !y[i]) tn++; else fn++;
  });
  const n = X.length || 1;
  const precision = tp / (tp + fp || 1);
  const recall = tp / (tp + fn || 1);
  return {
    samples: X.length,
    accuracy: (tp + tn) / n,
    precision, recall,
    f1: precision + recall ? (2 * precision * recall) / (precision + recall) : 0,
    confusion: { tp, fp, tn, fn },
  };
}

// ---- Failure probability: logistic regression  P = 1/(1+e^-z)  (Paper 1, Sec. 4.3)
// Trained by batch gradient descent on the dataset's `train` split, evaluated on `test`.
function trainModel({ epochs = 3000, lr = 2.0 } = {}) {
  const ds = load();
  const prep = (rows) => ({ X: rows.map(toFeatures), y: rows.map((r) => r.failure) });
  const tr = prep(ds.train);
  const te = prep(ds.test);

  const w = new Array(N).fill(0);
  let b = 0;
  for (let e = 0; e < epochs; e++) {
    const gw = new Array(N).fill(0);
    let gb = 0;
    for (let i = 0; i < tr.X.length; i++) {
      const p = sigmoid(tr.X[i].reduce((s, v, j) => s + v * w[j], b));
      const err = p - tr.y[i];
      for (let j = 0; j < N; j++) gw[j] += err * tr.X[i][j];
      gb += err;
    }
    for (let j = 0; j < N; j++) w[j] -= (lr * gw[j]) / tr.X.length;
    b -= (lr * gb) / tr.X.length;
  }
  model = { w, b, trained: true };

  // data-driven Health Index weights: positive risk weights, normalised to sum 1
  const pos = w.map((x) => Math.max(x, 0));
  const s = pos.reduce((a, c) => a + c, 0) || 1;
  HI_WEIGHTS = pos.map((x) => x / s);

  const train = evaluate(tr.X, tr.y);
  const test = evaluate(te.X, te.y);
  model = { ...model, accuracy: test.accuracy, train, test, dataset: ds.file, failureRate: ds.failureRate };
  return model;
}

const failureProbability = (feats) => predictRaw(feats);

// feature contribution (explainability, Paper 1 Sec. 3.8: I_i ~ w_i * x_i)
const contributions = (feats) => feats.map((v, j) => model.w[j] * v);

// ---- Remaining Useful Life: RUL = Tf - Tc, estimated from HI trend (linear regression)
function estimateRUL(hours, his, threshold = 0.3) {
  const n = Math.min(40, his.length);
  if (n < 5) return null;
  const xs = hours.slice(-n);
  const ys = his.slice(-n);
  const mx = xs.reduce((a, b) => a + b, 0) / n;
  const my = ys.reduce((a, b) => a + b, 0) / n;
  let num = 0, den = 0;
  for (let i = 0; i < n; i++) { num += (xs[i] - mx) * (ys[i] - my); den += (xs[i] - mx) ** 2; }
  const slope = den === 0 ? 0 : num / den;
  const current = my + slope * (xs[n - 1] - mx);
  if (slope > -1e-4) return null;
  return Math.max(0, (current - threshold) / -slope);
}

const getModel = () => model;
const getHIWeights = () => HI_WEIGHTS;

module.exports = {
  trainModel, getModel, getHIWeights, healthIndex, failureProbability, contributions, estimateRUL, clip,
};

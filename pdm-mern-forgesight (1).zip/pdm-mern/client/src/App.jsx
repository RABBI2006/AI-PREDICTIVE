import React, { useEffect, useState, useCallback } from 'react';
import {
  LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, ResponsiveContainer, ReferenceLine, Legend,
} from 'recharts';
import * as api from './api.js';

const COLORS = { low: '#2e9e5b', medium: '#d9a400', high: '#e8730c', critical: '#d62839' };
const pct = (x, d = 1) => (x == null ? '-' : `${(x * 100).toFixed(d)}%`);
const money = (x) => (x == null ? '-' : `$${Math.round(x).toLocaleString()}`);

function Badge({ priority, failed }) {
  const p = failed ? 'critical' : priority || 'low';
  return <span className="badge" style={{ background: COLORS[p] }}>{failed ? 'FAILED' : p.toUpperCase()}</span>;
}

function Card({ label, value, sub, color }) {
  return (
    <div className="card kpi">
      <div className="kpi-label">{label}</div>
      <div className="kpi-value" style={color ? { color } : {}}>{value}</div>
      {sub && <div className="kpi-sub">{sub}</div>}
    </div>
  );
}

function Bar({ value, color }) {
  return (
    <div className="bar"><div className="bar-fill" style={{ width: `${Math.round(value * 100)}%`, background: color }} /></div>
  );
}

/* ---------------- Dataset model (ForgeSight) ---------------- */
const PF = [['temperature_C', 'Temperature (°C)', 85], ['vibration', 'Vibration (mm/s)', 6], ['rpm', 'RPM', 1500], ['operating_hours', 'Operating hours', 18000]];

function DatasetModel() {
  const [info, setInfo] = useState(null);
  const [v, setV] = useState(Object.fromEntries(PF.map(([k, , d]) => [k, d])));
  const [out, setOut] = useState(null);
  useEffect(() => { api.getModel().then(setInfo).catch(() => {}); }, []);
  const run = async () => setOut(await api.predict(Object.fromEntries(Object.entries(v).map(([k, x]) => [k, +x]))));
  if (!info) return null;
  const { dataset: d, model: m } = info;
  return (
    <div className="grid two">
      <div className="card">
        <h2>Dataset &amp; model</h2>
        <div className="result"><span>Dataset</span><b>{d.file}</b></div>
        <div className="result"><span>Rows (train / test)</span><b>{d.rows} ({d.train} / {d.test})</b></div>
        <div className="result"><span>Failure rate</span><b>{pct(d.failureRate)}</b></div>
        <div className="result"><span>Train accuracy</span><b>{pct(m.train.accuracy)}</b></div>
        <div className="result"><span>Test accuracy</span><b>{pct(m.test.accuracy)}</b></div>
        <div className="result"><span>Test precision / recall / F1</span><b>{pct(m.test.precision, 0)} / {pct(m.test.recall, 0)} / {pct(m.test.f1, 0)}</b></div>
        <div className="result"><span>Test confusion (TP / FP / TN / FN)</span><b>{m.test.confusion.tp} / {m.test.confusion.fp} / {m.test.confusion.tn} / {m.test.confusion.fn}</b></div>
      </div>
      <div className="card">
        <h2>Predict failure from dataset inputs</h2>
        {PF.map(([k, label]) => (
          <label key={k} className="field">{label}
            <input type="number" step="any" value={v[k]} onChange={(e) => setV({ ...v, [k]: e.target.value })} />
          </label>
        ))}
        <button onClick={run}>Predict</button>
        {out && (
          <p className="big" style={{ marginTop: 10 }}>
            {out.prediction.toUpperCase()} - probability {pct(out.failureProbability)}
            <span className="muted"> · top driver: {out.drivers[0].feature}</span>
          </p>
        )}
      </div>
    </div>
  );
}

/* ---------------- Dashboard ---------------- */
function Dashboard({ data, onOpen, onReseed }) {
  if (!data) return <p>Loading...</p>;
  const s = data.summary;
  return (
    <>
      <div className="grid kpis">
        <Card label="Machines monitored" value={s.total} />
        <Card label="Critical / High" value={`${s.critical} / ${s.high}`} color={s.critical ? COLORS.critical : undefined} />
        <Card label="Avg. Health Index" value={pct(s.avgHealth, 0)} />
        <Card label="Fleet availability" value={pct(s.fleetAvailability)} sub="Operating / (Operating + Downtime)" />
        <Card label="Avg. OEE" value={pct(s.avgOEE)} sub="OE = 0.4A + 0.3Q + 0.3P" />
        <Card label="Expected loss at risk" value={money(s.totalExpectedLoss)} sub={s.modelAccuracy ? `Dataset test accuracy ${pct(s.modelAccuracy)}` : ''} />
      </div>

      <DatasetModel />

      <div className="card">
        <div className="row between">
          <h2>Machine fleet</h2>
          <button className="ghost" onClick={onReseed}>Reset demo data</button>
        </div>
        <table>
          <thead>
            <tr><th>Machine</th><th>Type</th><th>Health</th><th>Failure prob.</th><th>RUL</th><th>Anomaly</th><th>Status</th><th /></tr>
          </thead>
          <tbody>
            {data.machines.map((m) => {
              const p = m.prediction || {};
              return (
                <tr key={m._id}>
                  <td><b>{m.name}</b><div className="muted">{m.location}</div></td>
                  <td>{m.type}</td>
                  <td style={{ minWidth: 130 }}>
                    {pct(p.healthIndex, 0)}
                    <Bar value={p.healthIndex ?? 0} color={COLORS[p.priority || 'low']} />
                  </td>
                  <td>{pct(p.failureProbability)}</td>
                  <td>{p.rulHours == null ? 'Stable' : `${Math.round(p.rulHours)} h`}</td>
                  <td>{p.isAnomaly ? 'Yes' : 'No'}</td>
                  <td><Badge priority={p.priority} failed={m.status === 'failed'} /></td>
                  <td><button onClick={() => onOpen(m._id)}>Open</button></td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </>
  );
}

/* ---------------- Machine detail ---------------- */
const SENSORS = ['temperature', 'vibration', 'rpm', 'operating_hours'];
const UNITS = { vibration: 'mm/s', temperature: '°C', rpm: 'rpm', operating_hours: 'h' };

function MachineDetail({ id, onBack }) {
  const [info, setInfo] = useState(null);
  const [series, setSeries] = useState([]);
  const [sensor, setSensor] = useState('temperature');
  const [steps, setSteps] = useState(10);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    const [i, s] = await Promise.all([api.getMachine(id), api.getSeries(id, 100)]);
    setInfo(i); setSeries(s);
  }, [id]);

  useEffect(() => { load(); }, [load]);

  const act = async (fn) => { setBusy(true); try { await fn(); await load(); } finally { setBusy(false); } };

  if (!info) return <p>Loading...</p>;
  const { machine: m, prediction: p, kpi } = info;
  const failed = m.status === 'failed';

  return (
    <>
      <div className="row between">
        <div>
          <button className="ghost" onClick={onBack}>← Back</button>
          <h2 style={{ display: 'inline', marginLeft: 12 }}>{m.name}</h2>{' '}
          <Badge priority={p?.priority} failed={failed} />
        </div>
        <div className="row">
          <input type="number" min="1" max="100" value={steps} onChange={(e) => setSteps(e.target.value)} style={{ width: 70 }} />
          <button disabled={busy} onClick={() => act(() => api.simulate(id, +steps))}>Simulate {steps} h</button>
          <button className="success" disabled={busy} onClick={() => act(() => api.maintain(id))}>Perform maintenance</button>
        </div>
      </div>

      <div className="grid kpis">
        <Card label="Health Index" value={pct(p?.healthIndex, 1)} color={COLORS[p?.priority || 'low']} />
        <Card label="Failure probability" value={pct(p?.failureProbability)} sub="Logistic regression" />
        <Card label="Remaining useful life" value={p?.rulHours == null ? 'Stable' : `${Math.round(p.rulHours)} h`} sub="RUL = Tf - Tc" />
        <Card label="Reliability (24 h)" value={pct(p?.reliability24h)} sub="R(t) = e^(-λt)" />
        <Card label="Availability" value={pct(kpi.availability)} />
        <Card label="OEE" value={pct(kpi.oee)} />
      </div>

      <div className="card decision" style={{ borderLeft: `6px solid ${COLORS[failed ? 'critical' : p?.priority || 'low']}` }}>
        <h3>Maintenance decision</h3>
        <p className="big">{p?.action}</p>
        <div className="row wrap muted">
          <span>Expected failure loss: <b>{money(p?.expectedLoss)}</b></span>
          <span>Preventive cost: <b>{money(p?.preventiveCost)}</b></span>
          <span>Anomaly score: <b>{p?.anomalyScore}</b> {p?.isAnomaly ? '(anomalous)' : ''}</span>
        </div>
        {p?.topFactors?.length > 0 && (
          <div className="muted" style={{ marginTop: 8 }}>
            Explainability - top drivers of failure risk:{' '}
            {p.topFactors.map((f) => `${f.feature} (${f.contribution})`).join(', ')}
          </div>
        )}
      </div>

      <div className="grid two">
        <div className="card">
          <h3>Health Index &amp; failure probability</h3>
          <ResponsiveContainer width="100%" height={260}>
            <LineChart data={series}>
              <CartesianGrid strokeDasharray="3 3" stroke="#8884" />
              <XAxis dataKey="hour" />
              <YAxis domain={[0, 1]} />
              <Tooltip />
              <Legend />
              <ReferenceLine y={0.3} stroke={COLORS.critical} strokeDasharray="4 4" label="Failure threshold" />
              <Line type="monotone" dataKey="hi" name="Health Index" stroke="#2e9e5b" dot={false} strokeWidth={2} />
              <Line type="monotone" dataKey="prob" name="Failure prob." stroke="#d62839" dot={false} strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="card">
          <div className="row between">
            <h3>Sensor stream</h3>
            <select value={sensor} onChange={(e) => setSensor(e.target.value)}>
              {SENSORS.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
          <ResponsiveContainer width="100%" height={260}>
            <LineChart data={series}>
              <CartesianGrid strokeDasharray="3 3" stroke="#8884" />
              <XAxis dataKey="hour" />
              <YAxis domain={['auto', 'auto']} unit={` ${UNITS[sensor]}`} width={80} />
              <Tooltip />
              <Line type="monotone" dataKey={sensor} stroke="#3b6fe0" dot={false} strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {m.maintenanceLog?.length > 0 && (
        <div className="card">
          <h3>Maintenance log</h3>
          <ul>{m.maintenanceLog.slice().reverse().map((l, i) => <li key={i}>{new Date(l.at).toLocaleString()} - {l.note}</li>)}</ul>
        </div>
      )}
    </>
  );
}

/* ---------------- Impact / ROI calculator ---------------- */
const FIELDS = [
  ['Dc', 'Downtime - conventional (h/yr)', 400], ['Dp', 'Downtime - predictive (h/yr)', 120],
  ['Cc', 'Maintenance cost - conventional ($)', 500000], ['Cp', 'Maintenance cost - predictive ($)', 340000],
  ['B', 'Total economic benefit ($)', 650000], ['C', 'Total implementation cost ($)', 250000],
  ['Rc', 'Reliability before', 0.82], ['Rp', 'Reliability after', 0.95],
  ['COb', 'CO₂ before (t)', 1200], ['COa', 'CO₂ after (t)', 980],
];
const LABELS = {
  downtimeReductionPct: 'Downtime reduction (DR)', costSavingPct: 'Cost saving (CS)', roiPct: 'Return on investment (ROI)',
  reliabilityImprovementPct: 'Reliability improvement (RI)', carbonReductionPct: 'Carbon reduction (CE)',
};

function Impact() {
  const [v, setV] = useState(Object.fromEntries(FIELDS.map(([k, , d]) => [k, d])));
  const [out, setOut] = useState(null);
  const run = async () => setOut(await api.calcImpact(Object.fromEntries(Object.entries(v).map(([k, x]) => [k, +x]))));
  useEffect(() => { run(); /* eslint-disable-next-line */ }, []);
  return (
    <div className="grid two">
      <div className="card">
        <h2>Impact &amp; ROI inputs</h2>
        {FIELDS.map(([k, label]) => (
          <label key={k} className="field">{label}
            <input type="number" step="any" value={v[k]} onChange={(e) => setV({ ...v, [k]: e.target.value })} />
          </label>
        ))}
        <button onClick={run}>Calculate</button>
      </div>
      <div className="card">
        <h2>Results</h2>
        {out && Object.entries(out).map(([k, val]) => (
          <div key={k} className="result"><span>{LABELS[k]}</span><b>{val}%</b></div>
        ))}
        <p className="muted">Formulas follow Paper 1, Sec. 5.6, 5.8 and 6.1-6.3.</p>
      </div>
    </div>
  );
}

/* ---------------- App shell ---------------- */
export default function App() {
  const [tab, setTab] = useState('dashboard');
  const [openId, setOpenId] = useState(null);
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);

  const refresh = useCallback(() => api.getDashboard().then(setData).catch((e) => setError(e.message)), []);
  useEffect(() => { refresh(); }, [refresh, tab, openId]);

  return (
    <div className="app">
      <header>
        <div>
          <h1>AI Predictive Maintenance</h1>
          <span className="muted">Industry 4.0 · cloud-edge-device IPdM lifecycle</span>
        </div>
        <nav>
          <button className={tab === 'dashboard' ? 'active' : ''} onClick={() => { setTab('dashboard'); setOpenId(null); }}>Dashboard</button>
          <button className={tab === 'impact' ? 'active' : ''} onClick={() => { setTab('impact'); setOpenId(null); }}>Impact &amp; ROI</button>
        </nav>
      </header>
      {error && <div className="card error">Cannot reach API: {error}. Is the server running on port 5000?</div>}
      <main>
        {tab === 'impact' && <Impact />}
        {tab === 'dashboard' && !openId && (
          <Dashboard data={data} onOpen={setOpenId} onReseed={async () => { await api.reseed(); refresh(); }} />
        )}
        {tab === 'dashboard' && openId && <MachineDetail id={openId} onBack={() => setOpenId(null)} />}
      </main>
    </div>
  );
}

import axios from 'axios';

const api = axios.create({ baseURL: '/api' });

export const getDashboard = () => api.get('/dashboard').then((r) => r.data);
export const getMachine = (id) => api.get(`/machines/${id}`).then((r) => r.data);
export const getSeries = (id, limit = 100) => api.get(`/machines/${id}/series`, { params: { limit } }).then((r) => r.data);
export const simulate = (id, steps) => api.post(`/machines/${id}/simulate`, { steps }).then((r) => r.data);
export const maintain = (id) => api.post(`/machines/${id}/maintain`).then((r) => r.data);
export const createMachine = (body) => api.post('/machines', body).then((r) => r.data);
export const deleteMachine = (id) => api.delete(`/machines/${id}`).then((r) => r.data);
export const reseed = () => api.post('/dashboard/seed').then((r) => r.data);
export const calcImpact = (body) => api.post('/kpi/impact', body).then((r) => r.data);
export const getModel = () => api.get('/model').then((r) => r.data);
export const predict = (body) => api.post('/model/predict', body).then((r) => r.data);
